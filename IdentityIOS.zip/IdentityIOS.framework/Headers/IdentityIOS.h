//
//  IdentityIOS.h
//  IdentityIOS
//
//  Created by Michael T on 01/03/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for IdentityIOS.
FOUNDATION_EXPORT double IdentityIOSVersionNumber;

//! Project version string for IdentityIOS.
FOUNDATION_EXPORT const unsigned char IdentityIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IdentityIOS/PublicHeader.h>


